<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * AutoCodeIgniter.com
 *
 * 基于CodeIgniter核心模块自动生成程序
 *
 * 源项目		AutoCodeIgniter
 * 作者：		AutoCodeIgniter.com Dev Team
 * 版权：		Copyright (c) 2015 , AutoCodeIgniter com.
 * 项目名称：销售 MODEL
 * 版本号：1 
 * 最后生成时间：2018-03-12 13:58:19 
 */
class Sale_model extends Base_Model {
	
    var $page_size = 10;
    function __construct()
	{
    	$this->db_tablepre = 't_aci_';
    	$this->table_name = 'sale';
		parent::__construct();
	}
    
    /**
     * 初始化默认值
     * @return array
     */
    function default_info()
    {
    	return array(
		'sale_id'=>0,
		'time'=>'',
		'brand'=>'',
		'series'=>'',
		'name'=>'',
		'in_price'=>'',
		'in_discount'=>'',
		'sale_price'=>'',
		'sale_discount'=>'',
		'profit'=>'',
		);
    }
    
    /**
     * 安装SQL表
     * @return void
     */
    function init()
    {
    	$this->query("CREATE TABLE  IF NOT EXISTS `t_aci_sale`
(
`time` datetime DEFAULT NULL COMMENT '时间',
`brand` varchar(250) DEFAULT NULL COMMENT '品牌',
`series` varchar(250) DEFAULT NULL COMMENT '系列',
`name` varchar(250) DEFAULT NULL COMMENT '产品名称',
`in_price` decimal(10,2) DEFAULT '0.00' COMMENT '进货价格',
`in_discount` varchar(250) DEFAULT NULL COMMENT '进货折扣',
`sale_price` decimal(10,2) DEFAULT '0.00' COMMENT '销售价格',
`sale_discount` varchar(250) DEFAULT NULL COMMENT '销售折扣',
`profit` varchar(250) DEFAULT NULL COMMENT '毛利',
`sale_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
PRIMARY KEY (`sale_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
");
    }
    
        }

// END sale_model class

/* End of file sale_model.php */
/* Location: ./sale_model.php */
?>